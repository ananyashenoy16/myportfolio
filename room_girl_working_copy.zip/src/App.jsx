import Spline from '@splinetool/react-spline';

export default function App() {
  return (
    <Spline scene="https://prod.spline.design/BATkJ4ASKpg7escM/scene.splinecode" />
  );
}
